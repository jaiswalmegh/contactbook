
import csv
from datetime import datetime
from pathlib import Path
from difflib import SequenceMatcher

FIELDS = [
    "id", "name", "phone", "email",
    "address", "favorite", "tags", "created_at"
]


class ContactDB:
    def __init__(self, file_path="contacts.txt"):
        supplied_path = Path(file_path)

        if supplied_path.is_absolute():
            self.file_path = supplied_path
        else:
            self.file_path = (
                Path(__file__).resolve().parent.parent / supplied_path
            )

        self._ensure_file()

    def _ensure_file(self):
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        if not self.file_path.exists():
            with self.file_path.open(
                "w", newline="", encoding="utf-8"
            ) as file:
                writer = csv.DictWriter(file, fieldnames=FIELDS)
                writer.writeheader()

    def _read_all(self):
        self._ensure_file()
        contacts = []

        try:
            with self.file_path.open(
                "r", newline="", encoding="utf-8"
            ) as file:
                reader = csv.DictReader(file)

                for row in reader:
                    if not row or not row.get("name"):
                        continue

                    contact = {
                        field: row.get(field, "") or ""
                        for field in FIELDS
                    }

                    try:
                        contact["id"] = int(contact["id"])
                    except (ValueError, TypeError):
                        contact["id"] = len(contacts) + 1

                    try:
                        contact["favorite"] = int(
                            contact["favorite"] or 0
                        )
                    except (ValueError, TypeError):
                        contact["favorite"] = 0

                    if not contact["created_at"]:
                        contact["created_at"] = datetime.now().isoformat(
                            timespec="seconds"
                        )

                    contacts.append(contact)

        except (OSError, csv.Error) as error:
            raise RuntimeError(
                f"Could not read {self.file_path.name}: {error}"
            ) from error

        return contacts

    def _write_all(self, contacts):
        try:
            with self.file_path.open(
                "w", newline="", encoding="utf-8"
            ) as file:
                writer = csv.DictWriter(
                    file,
                    fieldnames=FIELDS,
                    extrasaction="ignore"
                )
                writer.writeheader()
                writer.writerows(contacts)

        except (OSError, csv.Error) as error:
            raise RuntimeError(
                f"Could not save {self.file_path.name}: {error}"
            ) from error

    @staticmethod
    def _normalise(
        name, phone, email="", address="",
        favorite=0, tags="", created_at="", contact_id=0
    ):
        try:
            favorite_value = int(favorite or 0)
        except (ValueError, TypeError):
            favorite_value = 0

        return {
            "id": int(contact_id),
            "name": str(name or "").strip(),
            "phone": str(phone or "").strip(),
            "email": str(email or "").strip(),
            "address": str(address or "").strip(),
            "favorite": int(bool(favorite_value)),
            "tags": str(tags or "").strip(),
            "created_at": (
                str(created_at)
                if created_at
                else datetime.now().isoformat(timespec="seconds")
            ),
        }

    def add_contact(
        self, name, phone, email="",
        address="", favorite=0, tags=""
    ):
        name = str(name or "").strip()
        phone = str(phone or "").strip()

        if not name or not phone:
            return False

        contacts = self._read_all()

        if any(
            contact["phone"].casefold() == phone.casefold()
            for contact in contacts
        ):
            return False

        next_id = max(
            (contact["id"] for contact in contacts),
            default=0
        ) + 1

        contacts.append(
            self._normalise(
                name, phone, email, address,
                favorite, tags, contact_id=next_id
            )
        )

        self._write_all(contacts)
        return True

    def update_contact(
        self, contact_id, name, phone, email="",
        address="", favorite=0, tags=""
    ):
        try:
            contact_id = int(contact_id)
        except (ValueError, TypeError):
            return False

        name = str(name or "").strip()
        phone = str(phone or "").strip()

        if not name or not phone:
            return False

        contacts = self._read_all()

        for contact in contacts:
            if (
                contact["id"] != contact_id
                and contact["phone"].casefold() == phone.casefold()
            ):
                return False

        for index, contact in enumerate(contacts):
            if contact["id"] == contact_id:
                contacts[index] = self._normalise(
                    name,
                    phone,
                    email,
                    address,
                    favorite,
                    tags,
                    created_at=contact["created_at"],
                    contact_id=contact_id
                )

                self._write_all(contacts)
                return True

        return False

    def delete_contact(self, contact_id):
        try:
            contact_id = int(contact_id)
        except (ValueError, TypeError):
            return False

        contacts = self._read_all()
        remaining = [
            contact for contact in contacts
            if contact["id"] != contact_id
        ]

        if len(remaining) == len(contacts):
            return False

        self._write_all(remaining)
        return True

    def fetch_all(self, only_favorites=False):
        contacts = self._read_all()

        if only_favorites:
            contacts = [
                contact for contact in contacts
                if contact["favorite"]
            ]

        return sorted(
            contacts,
            key=lambda contact: contact["name"].casefold()
        )

    def search(self, keyword):
        keyword = str(keyword or "").casefold().strip()

        if not keyword:
            return []

        searchable_fields = (
            "name", "phone", "email", "address", "tags"
        )

        matches = [
            contact for contact in self._read_all()
            if any(
                keyword in str(contact.get(field, "")).casefold()
                for field in searchable_fields
            )
        ]

        return sorted(
            matches,
            key=lambda contact: contact["name"].casefold()
        )

    def find_similar(self, name, email=None, threshold=0.85):
        results = []
        name = str(name or "").strip().casefold()
        email = str(email or "").strip().casefold()

        for contact in self.fetch_all():
            score = SequenceMatcher(
                None, name, contact["name"].casefold()
            ).ratio()

            same_email = (
                bool(email)
                and bool(contact["email"])
                and email == contact["email"].casefold()
            )

            if score >= threshold or same_email:
                results.append({
                    "id": contact["id"],
                    "name": contact["name"],
                    "phone": contact["phone"],
                    "email": contact["email"],
                    "similarity": round(score, 2)
                })

        return results

    def close(self):
        # Kept for compatibility with existing project services.
        pass
