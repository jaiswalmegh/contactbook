# ui/search_view.py

import tkinter as tk
from tkinter import ttk
from theme.theme_manager import ThemeManager as T


class SearchView(tk.Frame):

    def __init__(self, parent, contact_service):
        super().__init__(parent, bg=T.current["bg"])
        self.service = contact_service
        self._build_ui()

    # ---------------- TREEVIEW THEME ----------------
    def _apply_tree_theme(self):
        style = ttk.Style()
        style.theme_use("default")

        style.configure(
            "Treeview",
            background=T.current["bg"],
            fieldbackground=T.current["bg"],
            foreground=T.current["text"],
            rowheight=30,
            borderwidth=0,
            relief="flat",
            font=("Segoe UI", 10)
        )

        style.configure(
            "Treeview.Heading",
            background=T.current["panel"],
            foreground=T.current["heading"],
            borderwidth=0,
            relief="flat",
            font=("Segoe UI Semibold", 10)
        )

        style.map(
            "Treeview",
            background=[("selected", T.current["select"])],
            foreground=[("selected", "#ffffff")]
        )

    # ---------------- UI ----------------
    def _build_ui(self):
        title = tk.Label(
            self,
            text="Search Contacts",
            font=("Segoe UI Semibold", 24),
            bg=T.current["bg"],
            fg=T.current["heading"]
        )
        title.pack(anchor="w", padx=24, pady=(20, 10))

        search_bar = tk.Frame(self, bg=T.current["bg"])
        search_bar.pack(fill="x", padx=24, pady=10)

        tk.Label(
            search_bar,
            text="Keyword:",
            font=("Segoe UI", 11),
            bg=T.current["bg"],
            fg=T.current["text"]
        ).pack(side="left", padx=(0, 10))

        self.search_entry = tk.Entry(
            search_bar,
            font=("Segoe UI", 11),
            bg=T.current["panel"],
            fg=T.current["text"],
            insertbackground=T.current["text"],
            relief="flat",
            width=40
        )
        self.search_entry.pack(side="left", padx=(0, 12))

        tk.Button(
            search_bar,
            text="Search",
            font=("Segoe UI", 10, "bold"),
            bg=T.current["accent"],
            fg="#000000",
            bd=0,
            padx=16,
            pady=8,
            command=self._search
        ).pack(side="left")

        table_container = tk.Frame(self, bg=T.current["bg"])
        table_container.pack(fill="both", expand=True, padx=24, pady=10)

        self._build_table(table_container)

    def _build_table(self, parent):
        self._apply_tree_theme()

        columns = ("id", "name", "phone", "email", "tags")

        self.tree = ttk.Treeview(
            parent,
            columns=columns,
            show="headings",
            selectmode="browse"
        )

        headings = {
            "id": "ID",
            "name": "Name",
            "phone": "Phone",
            "email": "Email",
            "tags": "Tags"
        }

        widths = {
            "id": 60,
            "name": 220,
            "phone": 160,
            "email": 260,
            "tags": 260
        }

        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(
                col,
                width=widths[col],
                anchor="center" if col == "id" else "w"
            )

        vsb = ttk.Scrollbar(parent, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(parent, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=vsb.set, xscroll=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

    # ---------------- ACTION ----------------
    def _search(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        keyword = self.search_entry.get().strip()
        if not keyword:
            return

        results = self.service.search_contacts(keyword)

        if not results:
            self.tree.insert(
                "",
                "end",
                values=("", "No results found", "", "", "")
            )
            return

        for c in results:
            self.tree.insert(
                "",
                "end",
                values=(
                    c["id"],
                    c["name"],
                    c["phone"],
                    c["email"],
                    c.get("tags", "")
                )
            )