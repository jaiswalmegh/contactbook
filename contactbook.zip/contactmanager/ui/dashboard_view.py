# ui/dashboard_view.py

import tkinter as tk
from theme.theme_manager import ThemeManager as T


class DashboardView(tk.Frame):

    def __init__(self, parent, analytics_service):
        super().__init__(parent, bg=T.current["bg"])
        self.analytics = analytics_service
        self._build_ui()

    def _build_ui(self):
        title = tk.Label(
            self,
            text="Dashboard",
            font=("Segoe UI Semibold", 24),
            bg=T.current["bg"],
            fg=T.current["heading"]
        )
        title.pack(anchor="w", padx=24, pady=(20, 10))

        stats_container = tk.Frame(self, bg=T.current["bg"])
        stats_container.pack(fill="x", padx=24, pady=10)

        total = self.analytics.total_contacts()
        favs = self.analytics.favorite_contacts()

        self._stat_card(stats_container, "Total Contacts", total)
        self._stat_card(stats_container, "Favorites", favs)

        tip = tk.Label(
            self,
            text="Use the sidebar to manage contacts efficiently.",
            font=("Segoe UI", 11),
            bg=T.current["bg"],
            fg=T.current["muted"]
        )
        tip.pack(anchor="w", padx=24, pady=(20, 0))

    def _stat_card(self, parent, label, value):
        card = tk.Frame(
            parent,
            bg=T.current["panel"],
            highlightbackground=T.current["select"],
            highlightthickness=1
        )
        card.pack(side="left", padx=10, pady=10, fill="x", expand=True)

        tk.Label(
            card,
            text=label,
            font=("Segoe UI", 11),
            bg=T.current["panel"],
            fg=T.current["muted"]
        ).pack(pady=(14, 4))

        tk.Label(
            card,
            text=value,
            font=("Segoe UI Black", 24),
            bg=T.current["panel"],
            fg=T.current["text"]
        ).pack(pady=(0, 14))