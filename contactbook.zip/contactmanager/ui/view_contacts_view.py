# ui/view_contacts_view.py

import tkinter as tk
from tkinter import ttk
from theme.theme_manager import ThemeManager as T


class ViewContactsView(tk.Frame):

    def __init__(self, parent, contact_service):
        super().__init__(parent, bg=T.current["bg"])
        self.service = contact_service
        self._build_ui()

    # ---------------- THEME (Treeview) ----------------
    def _apply_tree_theme(self):
        style = ttk.Style()
        style.theme_use("default")

        style.configure(
            "Treeview",
            background=T.current["bg"],
            fieldbackground=T.current["bg"],
            foreground=T.current["text"],
            rowheight=30,
            borderwidth=0,
            relief="flat",
            font=("Segoe UI", 10)
        )

        style.configure(
            "Treeview.Heading",
            background=T.current["panel"],
            foreground=T.current["heading"],
            borderwidth=0,
            relief="flat",
            font=("Segoe UI Semibold", 10)
        )

        style.map(
            "Treeview",
            background=[("selected", T.current["select"])],
            foreground=[("selected", "#ffffff")]
        )

    # ---------------- UI ----------------
    def _build_ui(self):
        title = tk.Label(
            self,
            text="View Contacts",
            font=("Segoe UI Semibold", 24),
            bg=T.current["bg"],
            fg=T.current["heading"]
        )
        title.pack(anchor="w", padx=24, pady=(20, 10))

        container = tk.Frame(self, bg=T.current["bg"])
        container.pack(fill="both", expand=True, padx=24, pady=10)

        self._build_table(container)
        self._load_contacts()

    def _build_table(self, parent):
        self._apply_tree_theme()

        columns = ("id", "name", "phone", "email", "favorite", "tags")

        self.tree = ttk.Treeview(
            parent,
            columns=columns,
            show="headings",
            selectmode="browse"
        )

        headings = {
            "id": "ID",
            "name": "Name",
            "phone": "Phone",
            "email": "Email",
            "favorite": "★",
            "tags": "Tags"
        }

        widths = {
            "id": 60,
            "name": 220,
            "phone": 160,
            "email": 260,
            "favorite": 60,
            "tags": 260
        }

        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(
                col,
                width=widths[col],
                anchor="center" if col in ("id", "favorite") else "w"
            )

        vsb = ttk.Scrollbar(parent, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(parent, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=vsb.set, xscroll=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

    # ---------------- DATA ----------------
    def _load_contacts(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        contacts = self.service.get_all_contacts()

        if not contacts:
            self.tree.insert(
                "",
                "end",
                values=("", "No contacts found", "", "", "", "")
            )
            return

        for c in contacts:
            self.tree.insert(
                "",
                "end",
                values=(
                    c["id"],
                    c["name"],
                    c["phone"],
                    c["email"],
                    "⭐" if c.get("favorite") else "",
                    c.get("tags", "")
                )
            )