# ui/delete_contact_view.py

import tkinter as tk
from theme.theme_manager import ThemeManager as T


class DeleteContactView(tk.Frame):

    def __init__(self, parent, contact_service):
        super().__init__(parent, bg=T.current["bg"])
        self.service = contact_service
        self._build_ui()

    # ---------------- UI ----------------
    def _build_ui(self):
        title = tk.Label(
            self,
            text="Delete Contact",
            font=("Segoe UI Semibold", 24),
            bg=T.current["bg"],
            fg=T.current["danger"]
        )
        title.pack(anchor="w", padx=24, pady=(20, 10))

        card = tk.Frame(
            self,
            bg=T.current["panel"],
            highlightbackground=T.current["danger"],
            highlightthickness=1
        )
        card.pack(fill="x", padx=24, pady=10)

        self.id_entry = self._field(card, "Contact ID", 0)

        self.status_lbl = tk.Label(
            card,
            text="",
            font=("Segoe UI", 10),
            bg=T.current["panel"],
            fg=T.current["muted"]
        )
        self.status_lbl.grid(row=1, column=0, columnspan=2, sticky="w", padx=12)

        tk.Button(
            card,
            text="Delete Contact",
            font=("Segoe UI", 12, "bold"),
            bg=T.current["danger"],
            fg="#ffffff",
            bd=0,
            padx=18,
            pady=10,
            command=self._delete_contact
        ).grid(row=2, column=1, sticky="e", padx=12, pady=16)

        card.grid_columnconfigure(1, weight=1)

    def _field(self, parent, label, row):
        tk.Label(
            parent,
            text=f"{label}:",
            font=("Segoe UI", 11),
            bg=T.current["panel"],
            fg=T.current["text"]
        ).grid(row=row, column=0, sticky="w", padx=12, pady=6)

        entry = tk.Entry(
            parent,
            font=("Segoe UI", 11),
            bg=T.current["bg"],
            fg=T.current["text"],
            insertbackground=T.current["text"],
            relief="flat"
        )
        entry.grid(row=row, column=1, sticky="we", padx=12, pady=6)
        return entry

    # ---------------- ACTION ----------------
    def _delete_contact(self):
        cid = self.id_entry.get().strip()

        if not cid.isdigit():
            self._set_status("Valid Contact ID required.", error=True)
            return

        ok, msg = self.service.delete_contact(int(cid))

        if ok:
            self._set_status("Contact deleted successfully.", error=False)
            self.id_entry.delete(0, tk.END)
        else:
            self._set_status(msg, error=True)

    # ---------------- HELPERS ----------------
    def _set_status(self, message, error=False):
        self.status_lbl.configure(
            text=message,
            fg=T.current["danger"] if error else T.current["heading"]
        )