# ui/update_contact_view.py

import tkinter as tk
from theme.theme_manager import ThemeManager as T


class UpdateContactView(tk.Frame):

    def __init__(self, parent, contact_service):
        super().__init__(parent, bg=T.current["bg"])
        self.service = contact_service
        self._build_ui()

    # ---------------- UI ----------------
    def _build_ui(self):
        title = tk.Label(
            self,
            text="Update Contact",
            font=("Segoe UI Semibold", 24),
            bg=T.current["bg"],
            fg=T.current["heading"]
        )
        title.pack(anchor="w", padx=24, pady=(20, 10))

        card = tk.Frame(
            self,
            bg=T.current["panel"],
            highlightbackground=T.current["select"],
            highlightthickness=1
        )
        card.pack(fill="x", padx=24, pady=10)

        self.id_entry = self._field(card, "Contact ID", 0)
        self.name_entry = self._field(card, "Name", 1)
        self.phone_entry = self._field(card, "Phone", 2)
        self.email_entry = self._field(card, "Email", 3)
        self.address_entry = self._field(card, "Address", 4)
        self.tags_entry = self._field(card, "Tags", 5)

        self.fav_var = tk.IntVar(value=0)
        tk.Checkbutton(
            card,
            text="Favorite ⭐",
            variable=self.fav_var,
            bg=T.current["panel"],
            fg=T.current["text"],
            selectcolor=T.current["panel"],
            activebackground=T.current["panel"]
        ).grid(row=6, column=1, sticky="w", padx=12, pady=8)

        self.status_lbl = tk.Label(
            card,
            text="",
            font=("Segoe UI", 10),
            bg=T.current["panel"],
            fg=T.current["muted"]
        )
        self.status_lbl.grid(row=7, column=0, columnspan=2, sticky="w", padx=12)

        tk.Button(
            card,
            text="Save Changes",
            font=("Segoe UI", 12, "bold"),
            bg=T.current["accent"],
            fg="#000000",
            bd=0,
            padx=18,
            pady=10,
            command=self._update_contact
        ).grid(row=8, column=1, sticky="e", padx=12, pady=16)

        card.grid_columnconfigure(1, weight=1)

    def _field(self, parent, label, row):
        tk.Label(
            parent,
            text=f"{label}:",
            font=("Segoe UI", 11),
            bg=T.current["panel"],
            fg=T.current["text"]
        ).grid(row=row, column=0, sticky="w", padx=12, pady=6)

        entry = tk.Entry(
            parent,
            font=("Segoe UI", 11),
            bg=T.current["bg"],
            fg=T.current["text"],
            insertbackground=T.current["text"],
            relief="flat"
        )
        entry.grid(row=row, column=1, sticky="we", padx=12, pady=6)
        return entry

    # ---------------- ACTION ----------------
    def _update_contact(self):
        cid = self.id_entry.get().strip()

        if not cid.isdigit():
            self._set_status("Valid Contact ID required.", error=True)
            return

        ok, msg = self.service.update_contact(
            contact_id=int(cid),
            name=self.name_entry.get(),
            phone=self.phone_entry.get(),
            email=self.email_entry.get(),
            address=self.address_entry.get(),
            favorite=self.fav_var.get(),
            tags=self.tags_entry.get()
        )

        if ok:
            self._set_status("Contact updated successfully.", error=False)
        else:
            self._set_status(msg, error=True)

    # ---------------- HELPERS ----------------
    def _set_status(self, message, error=False):
        self.status_lbl.configure(
            text=message,
            fg=T.current["danger"] if error else T.current["heading"]
        )