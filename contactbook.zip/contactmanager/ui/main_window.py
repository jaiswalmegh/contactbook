import tkinter as tk

from theme.theme_manager import ThemeManager as T

from ui.dashboard_view import DashboardView
from ui.add_contact_view import AddContactView
from ui.view_contacts_view import ViewContactsView
from ui.search_view import SearchView
from ui.update_contact_view import UpdateContactView
from ui.delete_contact_view import DeleteContactView




class MainWindow:

    def __init__(self, root, contact_service, analytics_service, chatbot_service=None):

        self.root = root
        self.contact_service = contact_service
        self.analytics_service = analytics_service
        self.chatbot_service = chatbot_service

        self.current_view = None

        self._configure_window()
        self._build_layout()
        self._build_sidebar()

        self.show_dashboard()

    # ---------------- WINDOW ----------------
    def _configure_window(self):

        self.root.title("Contact Manager")
        self.root.geometry("1200x720")
        self.root.minsize(1050, 650)
        self.root.configure(bg=T.current["bg"])

    # ---------------- LAYOUT ----------------
    def _build_layout(self):

        self.container = tk.Frame(self.root, bg=T.current["bg"])
        self.container.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(
            self.container,
            width=240,
            bg=T.current["sidebar"]
        )
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        self.content = tk.Frame(
            self.container,
            bg=T.current["bg"]
        )
        self.content.pack(side="right", fill="both", expand=True)

    # ---------------- SIDEBAR ----------------
    def _build_sidebar(self):

        tk.Label(
            self.sidebar,
            text="📒 Contact Manager",
            font=("Segoe UI Semibold", 16),
            bg=T.current["sidebar"],
            fg=T.current["heading"]
        ).pack(pady=(20, 30))

        self._nav_button("Dashboard", self.show_dashboard)
        self._nav_button("Add Contact", self.show_add)
        self._nav_button("View Contacts", self.show_view)
        self._nav_button("Search", self.show_search)
        self._nav_button("Update Contact", self.show_update)
        self._nav_button("Delete Contact", self.show_delete)

        

        tk.Frame(
            self.sidebar,
            bg=T.current["sidebar"]
        ).pack(expand=True, fill="both")

        tk.Button(
            self.sidebar,
            text="Exit",
            font=("Segoe UI", 12, "bold"),
            bg=T.current["danger"],
            fg="white",
            bd=0,
            pady=10,
            command=self.root.quit
        ).pack(fill="x", padx=16, pady=16)

    def _nav_button(self, text, command):

        tk.Button(
            self.sidebar,
            text=text,
            font=("Segoe UI", 12),
            bg=T.current["panel"],
            fg=T.current["text"],
            activebackground=T.current["select"],
            activeforeground="#ffffff",
            bd=0,
            pady=10,
            anchor="w",
            command=command
        ).pack(fill="x", padx=16, pady=6)

    # ---------------- VIEW SWITCHING ----------------
    def _set_view(self, view):

        if self.current_view:
            self.current_view.destroy()

        self.current_view = view
        self.current_view.pack(fill="both", expand=True)

    # ---------------- VIEWS ----------------
    def show_dashboard(self):

        self._set_view(
            DashboardView(self.content, self.analytics_service)
        )

    def show_add(self):

        self._set_view(
            AddContactView(self.content, self.contact_service)
        )

    def show_view(self):

        self._set_view(
            ViewContactsView(self.content, self.contact_service)
        )

    def show_search(self):

        self._set_view(
            SearchView(self.content, self.contact_service)
        )

    def show_update(self):

        self._set_view(
            UpdateContactView(self.content, self.contact_service)
        )

    def show_delete(self):

        self._set_view(
            DeleteContactView(self.content, self.contact_service)
        )

    # ---------------- CHATBOT ----------------
    