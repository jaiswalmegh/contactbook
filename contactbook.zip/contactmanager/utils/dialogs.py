# utils/dialogs.py

from tkinter import messagebox


class Dialogs:
    """
    Centralized dialog helpers for the application.
    UI files should use these instead of calling messagebox directly.
    """

    @staticmethod
    def info(title, message):
        messagebox.showinfo(title, message)

    @staticmethod
    def warning(title, message):
        messagebox.showwarning(title, message)

    @staticmethod
    def error(title, message):
        messagebox.showerror(title, message)

    @staticmethod
    def confirm(title, message):
        """
        Yes / No confirmation dialog.
        Returns True if user clicks Yes.
        """
        return messagebox.askyesno(title, message)