# utils/exporter.py

import csv
import json


class Exporter:
    """
    Handles exporting contact data to CSV and JSON.
    Pure utility module with no project-level dependencies.
    """

    @staticmethod
    def to_csv(file_path, rows, headers):
        """
        Export rows to a CSV file.

        :param file_path: destination file path
        :param rows: iterable of rows (list / tuple / dict-like)
        :param headers: list of column names
        """
        with open(file_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(headers)

            for row in rows:
                if isinstance(row, dict):
                    writer.writerow([row.get(h, "") for h in headers])
                else:
                    writer.writerow(row)

    @staticmethod
    def to_json(file_path, rows, headers):
        """
        Export rows to a JSON file.

        :param file_path: destination file path
        :param rows: iterable of rows
        :param headers: list of column names
        """
        data = []

        for row in rows:
            if isinstance(row, dict):
                data.append(row)
            else:
                data.append(dict(zip(headers, row)))

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)