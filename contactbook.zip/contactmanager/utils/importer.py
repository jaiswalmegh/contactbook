# utils/importer.py

import csv
import json


class Importer:
    """
    Handles importing contact data from CSV and JSON files.
    Pure utility module with no project-level dependencies.
    """

    @staticmethod
    def from_csv(file_path):
        """
        Read contacts from a CSV file.

        Expected headers (case-insensitive):
        name, phone, email, address, favorite, tags

        :return: list of dict records
        """
        records = []

        with open(file_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                records.append({
                    "name": (row.get("name") or row.get("Name") or "").strip(),
                    "phone": (row.get("phone") or row.get("Phone") or "").strip(),
                    "email": (row.get("email") or row.get("Email") or "").strip(),
                    "address": (row.get("address") or row.get("Address") or "").strip(),
                    "favorite": int(row.get("favorite") or row.get("Favorite") or 0),
                    "tags": (row.get("tags") or row.get("Tags") or "").strip()
                })

        return records

    @staticmethod
    def from_json(file_path):
        """
        Read contacts from a JSON file.

        Expected format:
        [
          {
            "name": "...",
            "phone": "...",
            "email": "...",
            "address": "...",
            "favorite": 0 or 1,
            "tags": "..."
          }
        ]
        """
        records = []

        with open(file_path, encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError("JSON file must contain a list of objects")

        for item in data:
            records.append({
                "name": str(item.get("name", "")).strip(),
                "phone": str(item.get("phone", "")).strip(),
                "email": str(item.get("email", "")).strip(),
                "address": str(item.get("address", "")).strip(),
                "favorite": int(bool(item.get("favorite", 0))),
                "tags": str(item.get("tags", "")).strip()
            })

        return records