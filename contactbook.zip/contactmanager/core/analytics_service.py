# core/analytics_service.py

from collections import Counter
from datetime import datetime


class AnalyticsService:
    """
    Provides analytics and statistics for contacts.
    Pure logic layer – no UI, no SQL queries.
    """

    def __init__(self, contact_db):
        self.db = contact_db

    # ---------------- BASIC STATS ----------------
    def total_contacts(self):
        return len(self.db.fetch_all())

    def favorite_contacts(self):
        return len(self.db.fetch_all(only_favorites=True))

    def unique_phone_count(self):
        contacts = self.db.fetch_all()
        phones = {c["phone"] for c in contacts}
        return len(phones)

    # ---------------- TAG ANALYTICS ----------------
    def tag_usage(self):
        """
        Returns tag frequency as dict.
        Example: {"family": 4, "office": 2}
        """
        counter = Counter()
        for c in self.db.fetch_all():
            tags = (c["tags"] or "").split(",")
            for t in tags:
                t = t.strip()
                if t:
                    counter[t] += 1
        return dict(counter)

    # ---------------- TIME ANALYTICS ----------------
    def contacts_by_month(self):
        """
        Groups contacts by YYYY-MM.
        Returns dict: {"2026-02": 5, "2026-01": 3}
        """
        counter = Counter()
        for c in self.db.fetch_all():
            created = c["created_at"]
            if not created:
                continue
            try:
                dt = datetime.fromisoformat(created)
                key = dt.strftime("%Y-%m")
                counter[key] += 1
            except ValueError:
                continue
        return dict(counter)

    # ---------------- DASHBOARD BUNDLE ----------------
    def dashboard_summary(self):
        """
        Returns all key analytics in one dict.
        UI can consume this directly.
        """
        return {
            "total_contacts": self.total_contacts(),
            "favorite_contacts": self.favorite_contacts(),
            "unique_phones": self.unique_phone_count(),
            "tag_usage": self.tag_usage(),
            "contacts_by_month": self.contacts_by_month()
        }