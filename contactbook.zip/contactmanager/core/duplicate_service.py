from difflib import SequenceMatcher


class DuplicateService:
    """
    Handles duplicate detection logic.
    Uses fuzzy name matching and exact email matching.
    """

    def __init__(self, contact_db):
        self.db = contact_db

    def find_duplicates(self, name, email=None, threshold=0.85, exclude_id=None):
        """
        Returns a list of possible duplicates with similarity scores.

        :param name: name to compare
        :param email: optional email for exact match
        :param threshold: similarity ratio (0–1)
        :param exclude_id: contact id to ignore (used during update)
        """
        name = (name or "").strip().lower()
        email = (email or "").strip().lower() if email else None

        results = []
        rows = self.db.fetch_all()

        for row in rows:
            # row can be sqlite3.Row or tuple-like
            rid = row["id"]
            if exclude_id and rid == exclude_id:
                continue

            rname = (row["name"] or "").lower()
            remail = (row["email"] or "").lower() if row["email"] else None

            similarity = SequenceMatcher(None, name, rname).ratio()
            email_match = bool(email and remail and email == remail)

            if similarity >= threshold or email_match:
                results.append({
                    "id": rid,
                    "name": row["name"],
                    "phone": row["phone"],
                    "email": row["email"],
                    "similarity": round(similarity, 2),
                    "email_match": email_match
                })

        # sort best matches first
        results.sort(key=lambda x: (x["email_match"], x["similarity"]), reverse=True)
        return results