# core/contact_service.py

class ContactService:
    """
    Business logic layer.
    UI talks to this, this talks to ContactDB.
    """

    def __init__(self, contact_db):
        self.db = contact_db

    # ---------- ADD ----------
    def add_contact(self, name, phone, email="", address="", favorite=0, tags=""):
        name = name.strip()
        phone = phone.strip()

        if not name or not phone:
            return False, "Name and Phone are required."

        ok = self.db.add_contact(name, phone, email, address, favorite, tags)
        if not ok:
            return False, "Phone number already exists."

        return True, "Contact added successfully."

    # ---------- UPDATE ----------
    def update_contact(self, contact_id, name, phone, email, address, favorite, tags):
        if not contact_id:
            return False, "Invalid contact ID."

        ok = self.db.update_contact(
            contact_id, name, phone, email, address, favorite, tags
        )
        if not ok:
            return False, "Phone number already exists."

        return True, "Contact updated successfully."

    # ---------- DELETE ----------
    def delete_contact(self, contact_id):
        if not contact_id:
            return False, "Invalid contact ID."

        self.db.delete_contact(contact_id)
        return True, "Contact deleted."

    # ---------- FETCH ----------
    def get_all_contacts(self, favorites_only=False):
        return self.db.fetch_all(only_favorites=favorites_only)

    def search_contacts(self, keyword):
        if not keyword:
            return []
        return self.db.search(keyword)