# theme/theme_manager.py

class ThemeManager:
    """
    Central theme controller.
    Change colors here → whole app updates.
    """

    HIGH_CONTRAST = {
        # Layout
        "bg": "#020617",        # dark navy (not pure black)
        "panel": "#020617",
        "sidebar": "#020617",

        # Text
        "text": "#ffffff",
        "muted": "#cbd5e1",

        # Accents
        "heading": "#7dd3fc",   # soft cyan
        "accent": "#38bdf8",    # buttons
        "danger": "#ff1744",    # delete / exit
        "select": "#1e40af"     # selections
    }

    current = HIGH_CONTRAST