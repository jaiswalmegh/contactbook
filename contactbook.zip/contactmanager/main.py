
import tkinter as tk

from database.contact_db import ContactDB
from core.contact_service import ContactService
from core.analytics_service import AnalyticsService
from ui.main_window import MainWindow


def main():
    root = tk.Tk()

    # Contact details are stored in contacts.txt
    db = ContactDB("contacts.txt")

    contact_service = ContactService(db)
    analytics_service = AnalyticsService(db)

    MainWindow(
        root,
        contact_service=contact_service,
        analytics_service=analytics_service
    )

    root.mainloop()


if __name__ == "__main__":
    main()
